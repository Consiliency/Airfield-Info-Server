from django.apps import AppConfig


class AirportInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'airport_info'
